package com.mongo.reactive.springboot_reactive_mongo_crud_junit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootReactiveMongoCrudJunitApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootReactiveMongoCrudJunitApplication.class, args);
	}

}
